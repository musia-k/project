<?php

define('DB_HOST', 'localhost: 3307');
define('DB_USER', 'root');
define('DB_PASSWORD', 'root');
define('DB_NAME', 'db');

// connect to server
function connectDB() {
    $errorMessage = 'Cannot connect to the server';
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
    if (!$conn)
        throw new Exception($errorMessage);
    else {
        $query = $conn->query('set names utf8');
        if (!$query)
            throw new Exception($errorMessage);
        else
            return $conn;
    }
}

//  _GET
function getOptions() {
    // values
    $categoryId = (isset($_GET['category'])) ? (int)$_GET['category'] : 0;
    $minPrice = (isset($_GET['min_price'])) ? (int)$_GET['min_price'] : 0;
    $maxPrice = (isset($_GET['max_price'])) ? (int)$_GET['max_price'] : 1000000;
    $needsData = (isset($_GET['needs_data'])) ? explode(',', $_GET['needs_data']) : array();

    // brands
    $brands = (isset($_GET['brands'])) ? implode($_GET['brands'], ',') : null;

    // sorts
    $sort = (isset($_GET['sort'])) ? $_GET['sort'] : 'price_asc';
    $sort = explode('_', $sort);
    $sortBy = $sort[0];
    $sortDir = $sort[1];

    return array(
        'brands' => $brands,
        'category_id' => $categoryId,
        'min_price' => $minPrice,
        'max_price' => $maxPrice,
        'sort_by' => $sortBy,
        'sort_dir' => $sortDir,
        'needs_data' => $needsData
    );
}

// getting goods
function getGoods($options, $conn) {
    // imp data
    $minPrice = $options['min_price'];
    $maxPrice = $options['max_price'];
    $sortBy = $options['sort_by'];
    $sortDir = $options['sort_dir'];

    // usefull parameters
    $categoryId = $options['category_id'];
    $categoryWhere =
        ($categoryId !== 0)
            ? " g.category_id = $categoryId and "
            : '';

    $brands = $options['brands'];
    $brandsWhere =
        ($brands !== null)
            ? " g.brand_id in ($brands) and "
            : '';

    $query = "
        select
            g.id as good_id,
            g.good as good,
            g.category_id as category_id,
            b.brand as brand,
            g.price as price,
            g.rating as rating,
            g.photo as photo
            g.feature as feature
        from
            goods as g,
            brands as b
        where
            $categoryWhere
            $brandsWhere
            g.brand_id = b.id and
            (g.price between $minPrice and $maxPrice)
        order by $sortBy $sortDir
    ";

    $data = $conn->query($query);
    return $data->fetch_all(MYSQLI_ASSOC);
}

// brands by category
function getBrands($categoryId, $conn) {
    if ($categoryId !== 0) {
        $query = "
            select
                distinct b.id as id,
                b.brand as brand
            from
                brands as b,
                goods as g
            where
                g.category_id = $categoryId and
                g.brand_id = b.id
        ";
    } else {
        $query = 'select id, brand from brands';
    }
    $data = $conn->query($query);
    return $data->fetch_all(MYSQLI_ASSOC);
}

// get min and max price
function getPrices($categoryId, $conn) {
    $query = "
        select
            min(price) as min_price,
            max(price) as max_price
        from
            goods
    ";
    if ($categoryId !== 0) {
        $query .= " where category_id = $categoryId";
    }
    $data = $conn->query($query);
    return $data->fetch_assoc();
}

// all data
function getData($options, $conn) {
    $result = array(
        'goods' => getGoods($options, $conn)
    );

    $needsData = $options['needs_data'];
    if (empty($needsData)) return $result;

    if (in_array('brands', $needsData)) {
        $result['brands'] = getBrands($options['category_id'], $conn);
    }
    if (in_array('prices', $needsData)) {
        $result['prices'] = getPrices($options['category_id'], $conn);
    }

    return $result;
}


try {

    $conn = connectDB();

    $options = getOptions();

    $data = getData($options, $conn);

    echo json_encode(array(
        'code' => 'success',
        'data' => $data
    ));
}
catch (Exception $e) {
    // error
    echo json_encode(array(
        'code' => 'error',
        'message' => $e->getMessage()
    ));
}
