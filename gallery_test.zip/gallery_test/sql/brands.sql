﻿SET NAMES 'utf8';

--
-- Описание для таблицы brands
--
DROP TABLE IF EXISTS brands;
CREATE TABLE brands (
  id INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  brand VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (id)
)
ENGINE = INNODB
AUTO_INCREMENT = 7
AVG_ROW_LENGTH = 2730
CHARACTER SET utf8
COLLATE utf8_general_ci;


INSERT INTO brands VALUES
(1, 'Skoda'),
(2, 'Hyundai'),
(3, 'Suzuki'),
(4, 'Citroen'),
(5, 'Toyota'),
(6, 'Kia'),
(7, 'Audi'),
(8, 'Ford'),
(9, 'Volkswagen');
