﻿SET NAMES 'utf8';


DROP TABLE IF EXISTS goods;
CREATE TABLE goods (
  id INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  good VARCHAR(255) NOT NULL,
  category_id INT(10) UNSIGNED NOT NULL,
  brand_id INT(10) UNSIGNED NOT NULL,
  price INT(11) UNSIGNED NOT NULL,
  rating INT(11) UNSIGNED NOT NULL DEFAULT 0,
  photo VARCHAR(255) NOT NULL,
  feature VARCHAR(255) NOT NULL,
  PRIMARY KEY (id),
  CONSTRAINT FK_goods_brands_id FOREIGN KEY (brand_id)
    REFERENCES brands(id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT FK_goods_categories_id FOREIGN KEY (category_id)
    REFERENCES categories(id) ON DELETE CASCADE ON UPDATE CASCADE
)
ENGINE = INNODB
AUTO_INCREMENT = 15
AVG_ROW_LENGTH = 1170
CHARACTER SET utf8
COLLATE utf8_general_ci;

INSERT INTO goods VALUES
(1, 'Skoda Fabia', 1, 1, 18, 8, 'citroen.jpg', 'citroen_feature.jpg'),
(2, 'Hyundai Accent', 1, 2, 22, 9, 'hyundai.jpg','hyundai_feature.png'),
(3, 'Suzuki Vitara', 2, 3, 44, 5, 'suzuki.png', 'suzuki_feature.jpg'),
(4, 'Citroen C-Elysee', 1, 4, 24, 7, 'citroen.jpg','citroen_feature.jpg'),
(5, 'Hyundai Elantra 2019', 1, 2, 24, 8, 'hyudai5.jpg','hyudai5_feature.jpg');
