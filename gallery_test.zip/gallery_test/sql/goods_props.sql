﻿SET NAMES 'utf8';


CREATE TABLE goods_props (
  id INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  good_id INT(10) UNSIGNED NOT NULL,
  prop VARCHAR(255) NOT NULL,
  value VARCHAR(255) NOT NULL,
  PRIMARY KEY (id)
)
ENGINE = INNODB
AUTO_INCREMENT = 16
AVG_ROW_LENGTH = 1170
CHARACTER SET utf8
COLLATE utf8_general_ci;

INSERT INTO goods_props VALUES
(1, 1, ' ', '1.4 / Gasoline / Mechanic'),
(2, 2, ' ', '1.4 / Gasoline / Auto'),
(3, 3, ' ', '1.4 / Gasoline / Auto'),
(4, 4, ' ', '1.6 / Gasoline / Auto'),
(5, 5, ' ', '1.6 / Gasoline / Auto');
