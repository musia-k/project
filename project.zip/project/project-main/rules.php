<?php
$page = "rules";
include "header.php"; 
?> 

<!-- Create the content here -->
<main>
    <div class="container-content mx-auto">
        <div class="div-rules mx-auto">
            <h1 id="title1">Terms and Conditions</h1>
            <div class="row mx-auto">
                <div class="d-none d-sm-block col-md-4 left-column">
                    <img src="src/images/guideline.jpg" alt="guideline" id="guide-img">
                </div>
                
                <div class="col-12 col-md-8 right-column">
                    <div class="col-12 div-title"><h2>Chapter 1 ‒ General Provisions</h2></div>
                        <div class="col-12 div-article"> 
                            <div class="col-12 div-title-article"><h3>Article 1: Application of Agreement</h3></div>
                            <article>
                                <p>
                                    1. RMR CO., LTD. (hereinafter referred to as the “Company”) shall rent out a vehicle (hereinafter referred to as “Rental Car”) to the Renter, and the Renter shall rent the Rental Car from the Company, all in accordance with the provisions in this Agreement. 
                                    Matters not provided for in this Agreement shall be governed by relevant laws and regulations, and common practice.<br>
                                    2. The Company may make special provisions as long as they do not violate the purport of this Agreement, laws and regulations, administrative issuances, and common practice. If a special provision is made, such provision shall take precedence over this Agreement.<br>
                                    3. If the Renter has designated another Driver as described in Article 7, Paragraph 1, then the Renter shall ensure that the other Driver understands and complies with the provisions of this Agreement that concern the Driver.
                                    <br>
                                    <br>
                                </p>
                            </article>
                        </div>
                </div>
            </div>
        </div>
        
    
        <div class="div-rules mx-auto"> 
            <div class="row mx-auto">
                <h2>Chapter 2 ‒ Reservations</h2>
                <div class="col-12 col-md-6 left-column">    
                    <div class="col-12 div-article"> 
                        <div class="col-12 div-title-article"><h3>Article 2: Making a Reservation</h3></div>
                        <article>
                            <p>
                                1. Having consented to this Agreement, the separately prescribed price list, and other terms and conditions, the Renter may make a reservation, in accordance with the method separately provided by the Company, clearly specifying in advance the model or vehicle class, rental start date and time, rental location, rental period, return location, the name of the driver, requests for accessories such as toddler seats, and any other rental conditions (hereinafter referred to as “Rental Conditions”).<br>
                                2. When the Renter has made a reservation, the Company shall offer the Rental Cars for rent in its possession. Upon reservation, the Company may request payment of a separately prescribed reservation fee, and the Renter shall pay the fee accordingly.
                            </p>
                        </article>

                        <div class="col-12 div-title-article"><h3>Article 3: Changes to Reservations</h3></div>
                        <article>
                            <p>
                                The Renter must obtain the consent of the Company 
                                prior to the rental start date and time for any changes to the Rental Conditions provided for in paragraph 1 of the preceding Article.
                            <br>
                            <br>
                            </p>  
                        </article>

                        <div class="col-12 div-title-article"><h3>Article 4: Reservation Cancellations, etc.</h3></div>
                        <article>
                            <p>
                                1. The Renter may cancel a reservation by obtaining the consent of the Company. <br>
                                2. A reservation shall be deemed to have been cancelled when, due to the Renter’s circumstances, the procedure for concluding the Rental Car Rental Agreement (hereinafter referred to as “Rental Agreement”) has not been commenced within one (1) hour of the rental start time indicated in the reservation.<br>
                                3. If the Renter has failed to pay the reservation fee specified in Article 2, Paragraph 2, by the deadline specified by the Company, then the Company may cancel the reservation.<br>
                                4. If a reservation has been cancelled by virtue of the preceding two paragraphs, the Renter shall pay the Company the reservation cancellation fee prescribed separately by the Company. If the reservation cancellation fee has been paid when a reservation fee had been paid, the Company shall reimburse the Renter the reservation fee.<br> <br>
                            </p>
                        </article>

                    </div>
                </div>
                    
                <div class="col-12 col-md-6 right-column">   
                    <div class="col-12 div-article">

                        <div class="col-12 div-title-article"><h3>Article 5: Excemptions</h3></div>
                        <article>
                            <p>
                                Except in the cases provided for in the preceding Article, both the Company and the Renter shall not assume any liability whatsoever if a reservation is cancelled or a Rental Agreement is not concluded.
                            <br>
                            <br>
                            </p>  
                        </article>

                        <div class="col-12 div-title-article"><h3>Article 6: Reservation Agents</h3></div>
                        <article>
                            <p>
                                1. The Renter may make a reservation through a travel agency or an affiliated company (hereinafter referred to as “Agency”) that handles reservations on behalf of the Company. <br>
                                2. A Renter who has made a reservation through an Agency by virtue of the preceding paragraph, notwithstanding the provisions in Article 3 and Article 4, can only makes changes to or cancel the reservation with the concerned Agency.
                                <br><br>
                            </p>
                        </article>
                    </div>
                </div>
            </div>
        </div>

        <div class="div-rules mx-auto"> 
            <div class="row mx-auto">
                <h2>Chapter 3 ‒ Rental</h2>
                <div class="col-12 col-md-6 left-column">    
                    <div class="col-12 div-article"> 
                        <div class="col-12 div-title-article"><h3>Article 7: Rental Fees</h3></div>
                        <article>
                            <p>
                                1. Rental fees shall refer to the total of the following fees. The Company shall clearly state in the price list the amount, basis for calculation, and other details of each fee. <br>
                                <ul>
                                    <li>Basic fee</li>
                                    <li>Insurance/compensation fee (Safety Package fee, non-operation charge, Super Safety Package fee, etc.)</li>
                                    <li>Auxiliary fee (accessories/options)</li>
                                    <li>One-way (drop-off) fee</li>
                                    <li>Refueling/recharging fee</li>
                                    <li>Mileage fee (based on the distance traveled during the rental period)</li>
                                    <li>Car delivery/collection fee</li>
                                    <li>Other fees</li>
                                </ul>     
                                <br>                     
                                2. The basic fee shall be the fee in force the Company has filed with the Director of the relevant District Transport Bureau Branch at the time of concluding the Rental Agreement. <br>
                                3. If the Company revises the rental fees after a reservation has been established pursuant to Article 2, the applicable amount is the rental fees at the time of reservation or the rental fees at the time of concluding the Rental Agreement, whichever is lower.
                                <br>
                                <br>
                            </p>
                        </article>
                    </div>
                </div>
                    
                <div class="col-12 col-md-6 right-column">   
                    <div class="col-12 div-article">

                        <div class="col-12 div-title-article"><h3>Article 8: Cancellation of the Rental Agreement</h3></div>
                        <article>
                            <p>
                                If the Renter or the Driver has violated these Terms of Use while using the Rental Car or meets any of the descriptions enumerated under Article 8, Paragraph 1, then the Company may, with no notice or warning, release the Rental Agreement and immediately demand the return of the Rental Car and may process settlement as described below.
                                <br>
                                <ol>
                                    <li>If the Company already has received any rental fees, then it shall refund to the Renter the balance there of remaining after deducting the rental fees corresponding to the period from the actual handing over of the Rental Car to the Renter to the release of the Rental Agreement.</li>
                                    <li>If the Renter has caused any damage to the Company as described in Article 24, Paragraphs 1 and 2, then the Company shall demand from the Renter compensation for such damage.</li>
                                </ol>

                            <br>
                            <br>
                            </p>  
                        </article>
                    </div>
                </div>
            </div>
        </div>
    </div>

</main>
<!-- end of content -->

<?php include "footer.php"; ?> 