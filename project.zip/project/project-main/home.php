<?php
$page = "home";
include "header.php"; 
?> 

<!-- Create the content here -->
<main>

    <div class="container">
        <div class="row md-2">
            <div class="col-md-6"> 
                <div class="row md-2">
                    <div class="col-md-3">
                        <img src="src/images/car_main_page (1).png" alt="car">
                    </div>
                </div>
            </div>
            <div class="col-md-6"><h1>Available <br>Renting for Everyone ..</h1></div>
        </div>
    </div>

</main>
<!-- end of content -->

<?php include "footer.php"; ?> 