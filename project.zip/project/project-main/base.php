<?php include "header.php"; ?> 

<!-- Create the content here -->
<main>

</main>
<!-- end of content -->

<?php include "footer.php"; ?> 