<meta name="viewport" content="width=device-width, initial-scale=1.0"> 

<!-- google font -->
<link href='https://fonts.googleapis.com/css?family=Ubuntu:400,700&subset=latin,cyrillic-ext' rel='stylesheet' type='text/css'>

<!-- bootstrap3 -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

<!-- font awesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" crossorigin="anonymous" />

<!-- header footer -->
<link rel="stylesheet" href="css/header-footer.css">

<!-- main -->
<link href="css/main.css" rel="stylesheet" type="text/css">