
$("#toggle-nav").click( function (e) {
    e.preventDefault();
    $(".custom-navbar").toggleClass("mobile");
});