<!-- footer -->
<div class="custom-footer">
            <div class="container">
                <div class="row">
                    <div class="col_1">
                        <div class="text-footer">
                            <h3>Car Rental in Helsinki</h3>
                            <a href="gallery.html">Gallery</a> <br>
                            <a href="gallery.html">Special offers</a> <br>
                            <a href="gallery.html">Business renters</a> <br>
                            <a href="gallery.html">Vehicles</a>
                        </div>
                    </div>
                    <div class="col_2">
                        <div class="text-footer">
                            <h3>Customer Service</h3>
                            <a href="about-us.html">Contact us</a> <br>
                            <a href="faq.html">Frequently Asked Questions</a> 
                        </div>
                    </div>
                    <div class="col_3">
                    </div>
                    <div class="col_4">
                        <div class="text-footer">
                            <p>© 2021 <br>
                                RMR Car Rental.<br>
                                All rights reserved. Please read our Privacy Policy.<br>
                                Powered by Wheels Car Rental System
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end of footer -->
    </div> <!-- end container-main -->
  </body>
</html>