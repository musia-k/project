# Instruction

**STEP:**
1. Import the DB from src directory (project2.sql)
2. Copy sample-config.php to config.php (Inside adminpanel directory)
3. Modify the parameters needed inside the config file
4. Save and you are all set